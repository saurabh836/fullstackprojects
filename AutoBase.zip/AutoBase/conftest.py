import pytest, pprint
from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.desired_capabilities import DesiredCapabilities
from time import sleep
from Setup.read_xl import Xl
import os, time
from datetime import datetime


def pytest_addoption(parser):
    parser.addoption("--userID", action="store")
    parser.addoption("--password", action="store")


@pytest.fixture
def userID(request):
    return request.config.getoption("--userID")


@pytest.fixture
def password(request):
    return request.config.getoption("--password")


@pytest.fixture(scope="class")
def setup(request):
    # driver = webdriver.Remote(
    #     command_executor="http://192.168.1.25:4444/wd/hub",
    #     desired_capabilities={
    #         'browserName': 'chrome',
    #     }
    # )

    driver = webdriver.Chrome()
    driver.maximize_window()
    driver.implicitly_wait(3)
    request.cls.driver = driver
    yield driver
    driver.quit()


# set up a hook to be able to check if a test has failed
@pytest.hookimpl(tryfirst=True, hookwrapper=True)
def pytest_runtest_makereport(item, call):
    # execute all other hooks to obtain the report object
    outcome = yield
    rep = outcome.get_result()

    # set a report attribute for each phase of a call, which can
    # be "setup", "call", "teardown"

    setattr(item, "rep_" + rep.when, rep)


# check if a test has failed
@pytest.fixture(scope="function", autouse=True)
def test_failed_check(request, setup):
    yield
    # request.node is an "item" because we use the default
    # "function" scope
    if request.node.rep_setup.failed:
        print("setting up a test failed!", request.node.nodeid)
    elif request.node.rep_setup.passed:
        if request.node.rep_call.failed:
            driver = setup
            take_screenshot(driver, request.node.nodeid)
            print("executing test failed", request.node.nodeid)


# make a screenshot with a nameScreenshot of the test, date and time
def take_screenshot(driver, nodeid):
    time.sleep(1)
    file_name = f'{nodeid}_{datetime.today().strftime("%Y-%m-%d_%H:%M")}.png'.replace("/","_").replace("::","__")
    print(file_name)
    driver.save_screenshot("Screenshot/" + file_name)


# Test_data = Xl('/home/hp/PycharmProjects/AutoBase/Input/Test_Data.xlsx')
# login_field = Test_data.xl_data(1)
# login_data = Test_data.xl_data(-1)
# xl_write = Test_data.xl_write
# dict1 = [dict(zip(login_field, d)) for d in login_data if d != "None"]
#
#
# def pytest_generate_tests(metafunc):
#     if 'tes_num' in metafunc.fixturenames:
#         metafunc.parametrize('tes_num', dict1, scope='module')
