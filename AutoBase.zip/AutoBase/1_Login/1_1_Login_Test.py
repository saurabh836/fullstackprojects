import pytest
from time import sleep
from Setup.readCodex import ReadCodex
from Processes.Login import Login, Register
from Setup.read_xl import Xl


# ---Read Codex----
path = './Codex/codex1.txt'
r = ReadCodex(path)
get_ele = r.get_element
get_ele_txt = r.get_element_txt
sel_ele = r.select_ele
radio_ele = r.radio_txt
wait_for_ele = r.wait_for_ele_presn
get_main_window = r.get_main_window
switch_to_popup = r.switch_to_popup
switch_to_main = r.switch_to_main
check_element = r.test_element
element_click = r.element_click
ele_send_text = r.element_send_txt
# -----------

# ---Process---
vender_login = Login()
login = vender_login.login
usr_logout = vender_login.logout
register = Register()
user_register = register.register_user
reset_password = register.reset_password

# -------------

# ---domain
domain_name = "http://testjinn.com/medistaff/public/index.php/login"
# -----------


# ---Test Data----
# Test_data = Xl('/home/hp/PycharmProjects/AutoBase/Input/Test_Data.xlsx')
# login_field = Test_data.xl_data(1)
# login_data = Test_data.xl_data(-1)
# xl_write = Test_data.xl_write
# dict1 = [dict(zip(login_field, d)) for d in login_data if d != "None"]
# -----------


@pytest.mark.usefixtures("setup")
class TestLogin:
    @pytest.mark.skip
    def test_login1_test(self, userID, password):
        # print(userID, password)
        driver = self.driver
        usr_logout(driver)
        login(driver, userID, password)
        # driver.execute_script("document.body.style.zoom='80%'")
        sleep(5)
        logout = check_element(driver, "logout_btn")
        sleep(5)
        assert logout

    @pytest.mark.skip
    def test_login2(self, userID, password):
        print(userID, password)
        driver = self.driver
        # usr_logout(driver)
        login(driver, userID, password)
        logout = check_element(driver, "logout_btn")
        sleep(5)
        assert logout

    @pytest.mark.skip
    def test_login3(self):
        driver = self.driver
        driver.get("https://google.com")
        assert "aol" in driver.title


@pytest.mark.usefixtures("setup")
class TestRegistration:
    def test_register(self):
        driver = self.driver
        usr_email = "saurabh.sathe21@mailinator.com"
        smartcard_num = "123456801"
        logout_txt = user_register(driver, fname="Saurabh", lname="Sathe", location="Star Hospital",
                                   country="United Arab Emirates", email=usr_email,
                                   smartcard_number=smartcard_num, password="asdasd123", confirm_password="asdasd123")
        sleep(10)
        assert "Log Out" in logout_txt
        new_logout_txt = reset_password(driver, email=usr_email, new_password="asdasd@123")
        assert "Log Out" in new_logout_txt
