def read_file(file):
    with open(file, 'r+') as fr:
        r = fr.read().split("\n")
    return r


def write_file(file,  f_data):
    with open(file, 'w+') as fr:
        fr.write(f_data)
    return "Worte " + f_data


def replace_str(file, s_data, r_data):
    new_lines = "\n".join([x.replace(s_data, r_data) if x.find(s_data) > -1 else x for x in lines])
    write_file(file, new_lines)
    return new_lines


def append_file(file, f_data):
    with open(file, 'a+') as fr:
        fr.write("\n" + f_data)
    return "append " + f_data

