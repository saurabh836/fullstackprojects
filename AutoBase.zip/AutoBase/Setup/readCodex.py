from selenium import webdriver
import pytest
from time import sleep
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
from selenium.webdriver.support.wait import WebDriverWait
from selenium.common.exceptions import TimeoutException
from selenium.webdriver.support.ui import Select
from selenium.common.exceptions import NoSuchElementException
from selenium.webdriver.common.action_chains import ActionChains as ac
from selenium.webdriver.common.keys import Keys
from datetime import datetime


class ReadCodex(object):
    def __init__(self, path):
        self.path = path

    def chk_begin_with(self, line, char):
        chk = False
        if line[:len(char)] == char:
            chk = True
        return chk

    def removewhite(self, string):
        if string.count("  ") > 0:
            string = string.replace("  ", " ")
            return self.removewhite(string)
        else:
            return string

    def read_codex_line(self, path):
        codex_file = open(path, 'r')
        codex_line = codex_file.read().split("\n")
        codex_dict = []
        for line in codex_line:
            if self.chk_begin_with(line, "#"):
                pass
            else:
                line = self.removewhite(line)
                codex_dict.append(line.split(" ", 2))
        return codex_dict

    def read_codex_line_new(self, path):
        codex_file = open(path, 'r')
        codex_line = codex_file.read().split("\n")
        codex_dict = []
        for line in codex_line:
            if self.chk_begin_with(line, "#"):
                pass
            else:
                line = self.removewhite(line)
                codex_dict.append(line.split(" ", 3))
        return codex_dict

    def get_codex(self, codexname):
        codex_dict = self.read_codex_line(self.path)
        # print codex_dict
        # codexname, codextype, codex
        ele = ''
        for codex_set in codex_dict:
            if codex_set[0] == codexname:
                codex = codex_set[2][1:-1]
                ele = codex_set[1], codex
        return ele

    def get_codex_new(self, codexname):
        codex_dict = self.read_codex_line(self.path)
        ele = ''
        for codex_set in codex_dict:
            if codex_set[0] == codexname:
                codex = codex_set[2][1:-1]
                ele = codex_set[1], codex, codex_set[3]
        return ele

    def get_element(self, driver, codexname, part=None):
        if not codexname:
            pass
        else:
            codex_type, codex = self.get_codex(codexname)
            if part:
                codex_type, codex = self.create_xpath(codexname, part)
            # print(codexname, codex_type, codex)
            element = None
            if codex_type == "id":
                try:
                    element = driver.find_element_by_id(codex)
                except NoSuchElementException:
                    print("NoSuchElementException")
                    sleep(10)
                    element = driver.find_element_by_id(codex)
            elif codex_type == "xpath":
                element = driver.find_element_by_xpath(codex)
            elif codex_type == "name":
                element = driver.find_element_by_name(codex)
            # self.move_to_view(driver, element)
            # driver.execute_script("arguments[0].scrollIntoView();", element)
            # sleep(5)
            return element

    def wait_for_page(self, driver, ele_chk):
        codex_type, codex = self.get_codex(ele_chk)
        # print codex
        try:
            WebDriverWait(driver, 30).until(EC.presence_of_element_located((By.ID, codex)))
        except TimeoutException:
            assert False

    def wait_for_ele_presn(self, driver, ele_chk):
        codex_type, codex = self.get_codex(ele_chk)
        try:
            WebDriverWait(driver, 180).until(
                EC.presence_of_element_located((eval("By." + codex_type.upper()), codex)))
        except (NoSuchElementException, TimeoutException) as py_ex:
            print(py_ex)

    def wait_for_ele_visible(self, driver, ele_chk):
        # codex_type, codex = self.get_codex(ele_chk)
        try:
            WebDriverWait(driver, 60).until(
                EC.visibility_of(self.get_element(driver, ele_chk)))
            sleep(1)
        except (NoSuchElementException, TimeoutException) as py_ex:
            print(py_ex)

    def test_ele_visible(self, driver, ele_chk):
        return self.get_element(driver, ele_chk).is_displayed()

    def wait_for_ele_click(self, driver, ele_chk):
        codex_type, codex = self.get_codex(ele_chk)
        try:
            WebDriverWait(driver, 60).until(
                EC.element_to_be_clickable((eval("By." + codex_type.upper()), codex)))
        except (NoSuchElementException, TimeoutException) as py_ex:
            print(py_ex)

    def select_ele(self, driver, selectele, value):
        # print("abc" + selectele)
        codex_type, codex = self.get_codex(selectele)
        locator = driver.find_element_by_id
        if codex_type == "id":
            locator = driver.find_element_by_id
        elif codex_type == "xpath":
            locator = driver.find_element_by_xpath
        try:
            select = Select(locator(codex))
            select.select_by_value(value)
        except NoSuchElementException:
            try:
                select = Select(locator(codex))
                select.select_by_value(value.lower())
            except NoSuchElementException:
                select = Select(locator(codex))
                select.select_by_visible_text(value)
        return driver

    def radio_txt(self, driver, radioele, value):
        codex_type, codex = self.get_codex(radioele)
        rad_ele = driver.find_element_by_xpath("//*[@id=" + chr(34) + codex + chr(34) + "]" +
                                               "/descendant::input[@value=" + chr(34) + value + chr(34) + "]")
        rad_ele.click()

    def get_element_txt(self, driver, codexname):
        codex_type, codex = self.get_codex(codexname)
        element_txt = None
        if codex_type == "id":
            element = driver.find_element_by_id(codex)
            # self.move_to_view(driver, element)
            element_txt = element.text
        elif codex_type == "xpath":
            element = driver.find_element_by_xpath(codex)
            # self.move_to_view(driver, element)
            element_txt = element.text
        return element_txt

    def move_to_view(self, driver, ele):
        actions = ac(driver)
        print("XXXXXXXXXXXXXXXXXX")
        actions.move_to_element(ele)
        actions.perform()
        return ele

    def get_main_window(self, driver):
        window_before = driver.window_handles[0]
        return window_before

    def switch_to_popup(self, driver):
        window_after = driver.window_handles[1]
        driver.switch_to_window(window_after)
        return driver

    def open_new_tab(self, driver, page_url):
        driver.execute_script('window.open("' + page_url + '","_blank");')
        return driver

    def switch_to_main(self, driver):
        driver.switch_to_window(driver.window_handles[0])
        return driver

    def create_xpath(self, codexname, part):
        codex_type, codex = self.get_codex(codexname)
        # print(part)
        codex = codex.replace("||", str(part))
        return codex_type, codex

    def element_send_txt(self, driver, codexname, send_txt):
        ele = self.get_element(driver, codexname)
        try:
            ele.clear()
        except:
            pass
        ele.send_keys(send_txt)
        # sleep(3)
        return driver

    def element_click(self, driver, codexname, part=None):
        self.get_element(driver, codexname, part).click()
        # if part:
        #     self.get_element(driver, codexname, part).click()
        # else:
        #     self.get_element(driver, codexname).click()
        return driver

    def element_click_offset(self, driver, codexname):
        action = ac(driver)
        elem = self.get_element(driver, codexname)
        action.move_to_element(elem).move_by_offset(-50, 0).click().perform()

    def chk_chkbox_js(self, driver, codexname):
        codex_type, codex = self.get_codex(codexname)
        script = 'return document.getElementById("' + codex + '").checked = true;'
        driver.execute_script(script)
        return driver

    def datepicker_js(self, driver, codexname, value):
        codex_type, codex = self.get_codex(codexname)
        script = 'return document.getElementById("' + codex + '").value = ' + value + ';'
        driver.execute_script(script)
        return driver

    def chkbox_stus_js(self, driver, codexname):
        codex_type, codex = self.get_codex(codexname)
        script = 'return document.getElementById("' + codex + '").checked'
        return driver.execute_script(script)

    def test_element(self,  driver, codexname, part=None):
        try:
            if part:
                self.get_element(driver, codexname, part)
            else:
                self.get_element(driver, codexname)
            return True
        except Exception as e:
            print(e)
            return False

    def str_date(self, date_str, date_format):
        return datetime.strptime(date_str, date_format)


class NewReadCodex(ReadCodex):
    def read_codex_line_new(self, path):
        codex_file = open(path, 'r')
        codex_line = codex_file.read().split("\n")
        codex_dict = []
        for line in codex_line:
            if self.chk_begin_with(line, "#"):
                pass
            else:
                line = self.removewhite(line)
                codex_dict.append(line.split(" ", 3))
        return codex_dict

    def get_codex_new(self, codexname):
        codex_dict = self.read_codex_line(self.path)
        ele = ''
        for codex_set in codex_dict:
            # print(codex_set)
            if codex_set[0] == codexname:
                codex = codex_set[2][1:-1]
                ele = codex_set[1], codex, codex_set[3]
        return ele

    def get_element_new(self, driver, codexname, part=None):
        if not codexname:
            pass
        else:
            codex_type, codex, tag = self.get_codex_new(codexname)
            if part:
                codex = self.create_xpath(codexname, part)

            # print(codex_type, codex)
            element = None
            if codex_type == "id":
                element = driver.find_element_by_id(codex)
            elif codex_type == "xpath":
                element = driver.find_element_by_xpath(codex)
            elif codex_type == "name":
                element = driver.find_element_by_name(codex)
            # print(element)
            self.move_to_view(driver, element)
            return element, tag

    def action_type(self, driver, codexname, txt=None):
        ele, tag = self.get_element_new(driver, codexname)
        tags = ["txtbox", "click", "lbl", "selbox"]
        # sleep(5)
        if tag == "txtbox":
            ele.send_keys(txt)
            return driver
        elif tag == "selbox":
            try:
                select = Select(ele)
                select.select_by_value(txt)
            except NoSuchElementException:
                try:
                    select = Select(ele)
                    select.select_by_value(txt.lower())
                except NoSuchElementException:
                    select = Select(ele)
                    select.select_by_visible_text(txt)
            return driver
        elif tag == "lbl" and txt == "":
            return ele.text()
        elif tag == "click" and txt == "":
            ele.click()
            return driver


