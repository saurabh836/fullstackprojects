from openpyxl import Workbook, load_workbook
from pprint import pprint as pp
import pytest


class Xl:
    def __init__(self, path):
        self.path = path

    def xl_data(self, head=None):
        wb = load_workbook(self.path)
        sheet = wb.worksheets[0]

        r = sheet.max_row
        r0 = 1

        if head == 1:
            r = 1
        elif head == -1:
            r0 = 2

        c = sheet.max_column
        output = []
        for row in sheet.iter_rows(r0, r, 1, c):
            if row[1].value:
                temp = [cell.value for cell in row if cell.value is not None]
                # if row[0].row == 1:
                #     temp.append(str("row_no"))
                # else:
                #     temp.append(str(row[0].row))
                output.append(temp)
        if head == 1:
            return output[0]
        else:
            return output

    def xl_write(self, row, order_id):
        wb = load_workbook(self.path)
        sheet = wb.worksheets[0]
        sheet["A" + str(row)] = order_id
        wb.save(self.path)
        return "Order %s is saved" % order_id