from Setup.readCodex import ReadCodex
from time import sleep

# ---Read Codex----
path = './Codex/codex1.txt'
r = ReadCodex(path)
get_ele = r.get_element
get_ele_txt = r.get_element_txt
sel_ele = r.select_ele
radio_ele = r.radio_txt
wait_for_ele = r.wait_for_ele_presn
get_main_window = r.get_main_window
switch_to_popup = r.switch_to_popup
switch_to_main = r.switch_to_main
check_element = r.test_element
element_click = r.element_click
ele_send_text = r.element_send_txt
chk_chkbox_js = r.chk_chkbox_js
open_new_tab = r.open_new_tab
move_to_view = r.move_to_view
element_click_offset = r.element_click_offset
# -----------

# ---domain
domain_name = "http://testjinn.com/medistaff/public/index.php/login"
new_domain_name = "https://e-pointments.com/#/signup"
# -----------


class Login:
    @staticmethod
    def login(driver, UserID, Password):
        driver.get(domain_name)
        driver.implicitly_wait(30)
        get_ele(driver, "email_fld").send_keys(UserID)
        print("Email or Phone Number Entered.")
        get_ele(driver, "password_fld").send_keys(Password)
        print("Password Entered.")
        driver.implicitly_wait(10)
        btn = get_ele(driver, "login_btn")
        driver.execute_script("arguments[0].click();", btn)
        print("Submit Button Clicked.")
        driver.implicitly_wait(10)

    @staticmethod
    def logout(driver):
        driver.get('http://testjinn.com/medistaff/public/index.php/logout')


class Register:
    @staticmethod
    def register_user(driver, fname, lname, location, country, email, smartcard_number, password, confirm_password):
        driver.get(new_domain_name)
        sleep(5)
        driver.get(new_domain_name)
        sleep(5)
        get_ele(driver, "fname").send_keys(fname)
        get_ele(driver, "lname").send_keys(lname)
        get_ele(driver, "location").click()
        get_ele(driver, "loc").click()
        get_ele(driver, "country").click()
        get_ele(driver, "cnt").click()
        get_ele(driver, "email").send_keys(email)
        get_ele(driver, "smartcard_number").send_keys(smartcard_number)
        get_ele(driver, "password").send_keys(password)
        get_ele(driver, "confirm_password").send_keys(confirm_password)
        get_ele(driver, "tos").click()
        sleep(3)
        switch_to_popup(driver)
        driver.close()
        switch_to_main(driver)
        element_click_offset(driver, "agree")
        print("----------" + get_ele_txt(driver, "create_acc_btn"))
        element_click(driver, "create_acc_btn")
        sleep(15)

        # mailinator
        open_new_tab(driver, "https://www.mailinator.com/v3/index.jsp?zone=public&query=" + email.split("@")[0] +
                     "#/#inboxpane")
        sleep(3)
        switch_to_popup(driver)
        wait_for_ele(driver, "email_sub")
        element_click(driver, "email_sub")
        frame_element = driver.find_element_by_id("msg_body")
        move_to_view(driver, frame_element)
        driver.switch_to_frame(frame_element)
        # move_to_view(driver, get_ele(driver, "activation_link"))
        link = get_ele_txt(driver, "activation_link")
        driver.get(link)
        sleep(3)
        driver.get("https://e-pointments.com/#/")
        ele_send_text(driver, "eml_fld", email)
        ele_send_text(driver, "psd_fld", password)
        element_click(driver, "submit_btn")
        sleep(3)
        logout_txt = get_ele_txt(driver, "lout_btn")
        print("-----------------"+logout_txt)
        driver.get("https://e-pointments.com/#/doctor/logout")
        sleep(3)
        return logout_txt

    def reset_password(self, driver, email, new_password):
        driver.get("https://e-pointments.com/#/forgot-password")
        ele_send_text(driver, "email_field", email)
        element_click(driver, "reset_btn")
        sleep(5)
        driver.get("https://www.mailinator.com/v3/index.jsp?zone=public&query=" + email.split("@")[0] + "#/#inboxpane")
        wait_for_ele(driver, "reset_email_sub")
        element_click(driver, "reset_email_sub")
        frame_element = driver.find_element_by_id("msg_body")
        move_to_view(driver, frame_element)
        driver.switch_to_frame(frame_element)
        # move_to_view(driver, get_ele(driver, "activation_link"))
        link = get_ele(driver, "reset_link").get_attribute("href")
        print(link)
        driver.get(link)
        sleep(3)
        ele_send_text(driver, "new_pass", new_password)
        ele_send_text(driver, "confirm_new_pass", new_password)
        element_click(driver, "reset_btn")
        sleep(3)
        # login
        driver.get("https://e-pointments.com/#/")
        ele_send_text(driver, "eml_fld", email)
        ele_send_text(driver, "psd_fld", new_password)
        element_click(driver, "submit_btn")
        sleep(3)
        logout_txt = get_ele_txt(driver, "lout_btn")
        print("-----------------" + logout_txt)
        return logout_txt