package com.niit.skillmap;

import static org.junit.Assert.*;

import java.util.Date;

import org.junit.After;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.junit.jupiter.SpringJUnitConfig;
import org.springframework.test.context.junit4.SpringRunner;

import com.niit.skillmap.config.AppContext;
import com.niit.skillmap.entity.Employee;
import com.niit.skillmap.service.EmployeeService;


@RunWith(SpringRunner.class)
@SpringJUnitConfig(classes=AppContext.class)
public class AppTest {

	@Autowired
	EmployeeService employeeService;
	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testAddEmployee() {
		Employee emp=new Employee();
		emp.setEmployeeId(3);
		emp.setEmployeeName("smith");
		emp.setEmployeeEmail("smithn@gmail.com");
		emp.setEmployeeCity("mumbai");
		emp.setDate_of_joining(new Date());
		emp.setEmployeeCertification("java");
		emp.setEmployeePhone("9975975402");
		emp.setEmployeeQualification("be");
		emp.setEmployeeRole("employee");
		emp.setEmployeeSkill(".net");
		emp.setEmployeePassword("smith@1234");
		emp.setStatus(false);
		
		assertEquals(true, employeeService.addEmployee(emp));
	}
	@Ignore
	@Test
	
	public void testUpdateEmployee() {
		Employee emp=new Employee();
		emp.setEmployeeId(1);
		emp.setEmployeeName("amit");
		emp.setEmployeeEmail("amit@gmail.com");
		emp.setEmployeeCity("mumbai");
		emp.setDate_of_joining(new Date());
		emp.setEmployeeCertification("java");
		emp.setEmployeePhone("9978456123");
		emp.setEmployeeQualification("be");
		emp.setEmployeeRole("employee");
		emp.setEmployeeSkill("java");
		emp.setEmployeePassword("amit@123");
		emp.setStatus(false);
		
		assertEquals(true, employeeService.updateEmployee(emp));
	}


	@Ignore
	@Test
	public void testDeleteEmployee() {	
		assertEquals(true, employeeService.deleteEmployee(1));
	}

	
	@Ignore
	@Test
	public void testRetriveEmployee() {
		Employee emp=new Employee();
		Employee employee=employeeService.getEmployeeById(1);
		System.out.println(employee);
		assertEquals("",employeeService.getEmployeeById(1).getEmployeeId(),employee.getEmployeeId());
	}
    @Ignore
	@Test
	public void testRetriveAllEmployee() {
		assertEquals(2,employeeService.getAllEmployeeDetails().size());
	}
	
}
