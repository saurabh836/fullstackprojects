package com.niit.skillmap.SkillMapTest;
import com.niit.skillmap.config.DBConfig;
import com.niit.skillmap.dao.EmployeeDAO;
import com.niit.skillmap.daoimpl.EmployeeDAOImpl;
import com.niit.skillmap.model.Employee;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import static org.junit.Assert.assertEquals;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.Ignore;
import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.List;
import javax.swing.Spring;
import org.junit.runner.RunWith;


import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.context.annotation.Configuration;
import org.springframework.test.context.junit.jupiter.SpringJUnitConfig;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.junit.jupiter.SpringJUnitConfig;



@SpringJUnitConfig(classes=DBConfig.class)
@RunWith(SpringRunner.class)
public class SkillMapTest {
	@Autowired
    EmployeeDAO employeeDAO;
	@Before
	public void setup()
	{
		
	}
	
	@After
	public void tearDow()
	{
		
		
	}
	@Test
	public void insertemp()
	{
		Employee emp=new Employee();
		emp.setEmpid(1);
		emp.setEmpname("mukesh");
		emp.setEmailid("mukesh@gmail.com");
		emp.setPassword("123456");
		emp.setPhoneno("99789");
		emp.setRole("employee");
		emp.setActive(false);
		assertEquals(true,employeeDAO.addUser(emp));
		
			
		
	}
	
	@Ignore
	@Test
	public void viewempbyid()
	{
		assertEquals(true,employeeDAO.displayEmployeeById(2));
	}
	
	@Ignore
	@Test
	public void viewempdata()
	{
		assertEquals(6,employeeDAO.getallEmployee().size());
	}
	
	@Ignore
	@Test
	public void delempdata()
	{
		assertEquals(true,employeeDAO.deleteEmployee(2));
		System.out.println("success");
	}


}
