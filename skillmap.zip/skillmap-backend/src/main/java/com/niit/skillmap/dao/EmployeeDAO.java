package com.niit.skillmap.dao;
import java.util.List;

import com.niit.skillmap.model.Employee;
public interface EmployeeDAO {
	public boolean addUser(Employee user);
	public boolean updateUser(Employee user);
	public Employee displayEmployeeById(int empid);
	public boolean deleteEmployee(int empid);
	public List<Employee> getallEmployee();

}
